# Moss & Stone — Original static landing-page template

A responsive, five-section concept for a fictional home-cleaning business. Includes an original vector room illustration, accessible navigation and forms, an FAQ, and a local sample request builder. All code, illustration, and copy in this template are original. It uses system fonts and has no third-party runtime dependencies.

## Files

- `index.html` — Page content and original SVG illustration.
- `styles.css` — Responsive cream and forest-green design.
- `main.js` — Local request preview. It does not send or save information.
- `favicon.svg` — Original studio mark.

Open `index.html` to preview locally. This is a static frontend; it does not include hosting, domain registration, a payment processor, a booking service, or an inquiry backend. The sample request builder intentionally does not send requests. The banner clearly identifies the fictional concept.

When adapting this template to a real business, replace fictional service content with the business's actual offer and connect the contact action to its authorized contact method. Any external destination should be reviewed before publishing. Do not retain claims that do not match the real service.

## License

MIT License. Copyright (c) 2026 Rabil Ibraiel.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
